#include "Rock.h"
#include "Igneous.h"
#include <iostream>

using namespace std;

//Call the function 'Rock' from the file 'Rock.h'
Igneous::Igneous(int newDurability, string newColor, string newType, string newName, string newRoughness){

    roughness = newRoughness;

    durability = newDurability;
    color = newColor;
    type = newType;
    name = newName;

    cout <<"\n\n New Igneous Rock Created \n";
}

//Spills contents of this Igneous
void Igneous::Inspect() const{
    cout << "\n Inspecting " << name << "\n";
    cout << "Durability " << durability << "\n";
    cout << "Color " << color << "\n";
    cout << "Type " << type << "\n";
    cout << "Name " << name << "\n";
    cout << "Roughness " << roughness << "\n";
}

//Decreases value of durability
void Igneous::Chip(){
    durability = durability - 1;
    cout << name << "\n was chipped, its durability is now " << durability << "\n";
}