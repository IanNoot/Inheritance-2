#ifndef IGNEOUS_H
#define IGNEOUS_H

#include "Rock.h"
#include <string>

class Igneous : public Rock{

    private:

    std::string roughness = "NULL";

    public:
    
    //Constructor for Igneous
    Igneous(int newDurability, std::string newColor, std::string newType, std::string newName, std::string newRoughness);

    //S
    void Inspect() const;
    void Chip();
};


#endif