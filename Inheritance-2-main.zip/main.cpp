#include "Rock.h"
#include "Igneous.h"

#include <iostream>
#include <string>

using namespace std;

int main(){

    int emptyint = 0;

    //Creates a Rock named MyPebble
    Rock MyPebble(2, "White", "Quartz", "My Pebble");
    //Shows that all variables were applied correctly
    MyPebble.Inspect();

    //Creates an Igneous Rock named SpearTip
    Igneous SpearTip(3, "Black", "Obsidian", "Spear Tip", "Very Smooth");
    //Shows that all initial values applied
    SpearTip.Inspect();
    //Decreases health by one
    SpearTip.Chip();
    //Shows that health was successfully decreased
    SpearTip.Inspect();

    cin >> emptyint;

}