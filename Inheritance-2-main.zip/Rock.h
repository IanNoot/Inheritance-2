#ifndef ROCK_H
#define ROCK_H

#include <string>

class Rock{

    protected:
        //The number of hits that it takes to destroy a rock
        int durability = 0;

        //The color of the rock
        std::string color = "NULL";
        //The type/variety of the rock
        std::string type = "NULL";
        //The name of the rock
        std::string name = "NULL";


    public:
        //Constructor for rock
        Rock(int newDurability, std::string newColor, std::string newType, std::string newName);
        //Default constructor for rock
        Rock();
        //spills all variable in rock
        virtual void Inspect() const;

};

#endif // ROCK_H


