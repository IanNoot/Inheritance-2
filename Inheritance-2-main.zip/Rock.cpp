#include "Rock.h"
#include <iostream>

using namespace std;

//Call the function 'Rock' from the file 'Rock.h', This is the normal constructor
Rock::Rock(int newDurability, string newColor, string newType, string newName) : durability(newDurability), color(newColor), type(newType), name(newName){
    cout <<"\n\n New Rock Created \n";
}

//Default Constructor called when a child class is created
Rock::Rock(){
    cout << "\n\n New Rock Created";
}

//Spills contents of rock
void Rock::Inspect() const{
    cout << "\n Inspecting " << name << "\n";
    cout << "Durability " << durability << "\n";
    cout << "Color " << color << "\n";
    cout << "Type " << type << "\n";
    cout << "Name " << name << "\n\n";
}
